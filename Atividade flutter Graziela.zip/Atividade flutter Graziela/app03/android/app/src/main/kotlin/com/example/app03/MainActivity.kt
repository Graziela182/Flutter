package com.example.app03

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
