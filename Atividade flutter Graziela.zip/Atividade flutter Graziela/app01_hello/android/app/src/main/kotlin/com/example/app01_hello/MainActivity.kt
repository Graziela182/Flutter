package com.example.app01_hello

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
