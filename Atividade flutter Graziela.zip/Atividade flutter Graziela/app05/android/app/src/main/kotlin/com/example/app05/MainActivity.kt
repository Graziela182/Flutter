package com.example.app05

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
