package com.example.app08

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
