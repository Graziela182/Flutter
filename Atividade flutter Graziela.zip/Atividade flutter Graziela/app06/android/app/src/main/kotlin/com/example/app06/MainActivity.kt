package com.example.app06

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
