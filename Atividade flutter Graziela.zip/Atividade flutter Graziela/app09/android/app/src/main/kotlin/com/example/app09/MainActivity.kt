package com.example.app09

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
