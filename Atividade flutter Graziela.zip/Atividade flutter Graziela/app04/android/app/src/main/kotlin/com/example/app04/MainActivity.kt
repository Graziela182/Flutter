package com.example.app04

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
